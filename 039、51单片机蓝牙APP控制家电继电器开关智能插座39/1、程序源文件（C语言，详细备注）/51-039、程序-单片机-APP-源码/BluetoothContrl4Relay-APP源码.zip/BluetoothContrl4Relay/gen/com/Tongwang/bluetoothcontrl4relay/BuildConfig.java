/** Automatically generated file. DO NOT MODIFY */
package com.Tongwang.bluetoothcontrl4relay;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}