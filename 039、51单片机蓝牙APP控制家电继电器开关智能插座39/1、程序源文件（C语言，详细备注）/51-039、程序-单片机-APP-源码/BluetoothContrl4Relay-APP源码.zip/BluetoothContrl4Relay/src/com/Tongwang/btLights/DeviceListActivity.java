/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.Tongwang.btLights;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.Tongwang.bluetoothcontrl4relay.R;

/**
 * This Activity appears as a dialog. It lists any paired devices and
 * devices detected in the area after discovery. When a device is chosen
 * by the user, the MAC address of the device is sent back to the parent
 * Activity in the result Intent.
 */
public class DeviceListActivity extends Activity {//�豸�б���ͼ
    // Debugging
    private static final String TAG = "DeviceListActivity";
    private static final boolean D = true;

    // Return Intent extra
    public static String EXTRA_DEVICE_ADDRESS = "device_address";

    // Member fields
    private boolean isDiscoverable;
    private BluetoothAdapter mBtAdapter;
    private MyExpandableListAdapter mPairedDevicesAdapter;
    private String myBluetoothName;
    private String myBluetoothAddress;
    private ExpandableListView pListView;
	private TextView tv_myDeviceName = null;
	private TextView tv_myDeviceState = null;
	private CheckBox cb_isDiscoverable = null;
	private CountDownTimer discoveryableTimer;
	
	private ArrayList<HashMap<String, Object>> parentListItemData = new ArrayList<HashMap<String, Object>>();
	private ArrayList<ArrayList<HashMap<String, Object>>> childenListItemData = new ArrayList<ArrayList<HashMap<String, Object>>>();/* �������д������������豸���� */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Setup the window
        setContentView(R.layout.device_list);//������ͼ���

        // Set result CANCELED incase the user backs out
        setResult(Activity.RESULT_CANCELED);//����DeviceListActivity�����ú�ķ��ؽ��
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();//��ȡ��������������

		tv_myDeviceName = (TextView) findViewById(R.id.tv_myDeviceName);//������������������
		tv_myDeviceState = (TextView) findViewById(R.id.tv_myDeviceState);//���������������ɼ�״̬
		cb_isDiscoverable = (CheckBox) findViewById(R.id.cb_isDiscoverable);//��ѡʹ�������ɱ�����
		this.getMyBTInfo();// ��ñ�������������Ϣ
		tv_myDeviceName.setText(myBluetoothName);
		tv_myDeviceState.setText(myBluetoothAddress);
			if (mBtAdapter.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
				tv_myDeviceState.setText(myBluetoothAddress + "(�ɼ�)");
	
				// �����������ɼ�״̬ʱ��checkbox����Ҫ�ָ�ԭװ��ͨ��isChangeToDiscoverable����
				cb_isDiscoverable.setChecked(true);
				cb_isDiscoverable.setEnabled(false);
	
			} else {
				tv_myDeviceState.setText(myBluetoothAddress + "(���ɼ�)");
				cb_isDiscoverable.setChecked(false);
				cb_isDiscoverable.setEnabled(true);
			}
		cb_isDiscoverable.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					//  Auto-generated method stub
						if (isChecked) {
							discoveryable();
						}
					}
				});
		RelativeLayout myInfoLayout = (RelativeLayout)findViewById(R.id.layout_MyDeviceInfo);
		myInfoLayout.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if (!cb_isDiscoverable.isChecked()) {
					discoveryable();
				}
			}
		});
        // Initialize the button to perform device discovery
        final Button scanButton = (Button) findViewById(R.id.button_scan);//��ȡ�Զ����������ť
        scanButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	if(mBtAdapter.isDiscovering()){
            		mBtAdapter.cancelDiscovery();
            		scanButton.setText(R.string.button_scan);
            		findViewById(R.id.txt_state_search).setVisibility(View.GONE);
            	}
            	else{
                doDiscovery();//ִ������
                scanButton.setText(R.string.button_stop_scan);
        		findViewById(R.id.txt_state_search).setVisibility(View.VISIBLE);
            	}
            }
        });
        
        
        discoveryableTimer = new CountDownTimer(120000, 1000) {
			@Override
			public void onTick(long millisUntilFinished) {
				tv_myDeviceState.setText(myBluetoothAddress+"("+millisUntilFinished/1000+")");
			}
			
			@Override
			public void onFinish() {
				tv_myDeviceState.setText(myBluetoothAddress+"(���ɼ�)");
			}
		};
        
        
        

		HashMap<String, Object> map1 = new HashMap<String, Object>();
		map1.put("parentName", "������豸");
		map1.put("count","0");
		parentListItemData.add(map1);
		HashMap<String, Object> map2 = new HashMap<String, Object>();
		map2.put("parentName", "���������豸");
		map2.put("count","0");
		parentListItemData.add(map2);
		childenListItemData.add(new ArrayList<HashMap<String, Object>>());
		childenListItemData.add(new ArrayList<HashMap<String, Object>>());
        
        

        mPairedDevicesAdapter = new MyExpandableListAdapter(getApplicationContext(), 
        						parentListItemData, R.layout.list_item_parent, 
			        			new String[] {"parentName", "count" }, 
			        			new int[] { R.id.txt_parentName, R.id.txt_count }, 
			        			childenListItemData, R.layout.list_item_childen,  
		        				new String[] {"typeImage", "deviceName", "deviceAddress", "onRightImage" }, 
		        				new int[] { R.id.img_deviceType_1, R.id.txt_deviceName_1, R.id.txt_deviceAddress_1,R.id.img_onright_1 });//������豸�б�

        pListView = (ExpandableListView) findViewById(R.id.expandableListView1);//������豸��ʾ���
        pListView.setAdapter(mPairedDevicesAdapter);
        pListView.setOnChildClickListener(new OnChildClickListener() {
			@Override
			public boolean onChildClick(ExpandableListView parent, View view,
					int groupPosition, int childPosition, long id) {
	            mBtAdapter.cancelDiscovery();//ȡ������
	            String address = (String) childenListItemData.get(groupPosition).get(childPosition).get("deviceAddress");
	            // Create the result Intent and include the MAC address
	            Intent intent = new Intent();
	            intent.putExtra(EXTRA_DEVICE_ADDRESS, address);//֪ͨ����Activity������������豸�ĵ�ַ

	            // Set result and finish this Activity
	            setResult(Activity.RESULT_OK, intent);//���ø�Activity���صĽ�������ݣ�������ַ��
	            finish();//�������Activity
				return false;
			}
		});
        
        Set<BluetoothDevice> pairedDevices1 = mBtAdapter.getBondedDevices();//��ȡ����Ե������豸
        if (pairedDevices1.size() > 0) {//���������Ե������豸
            for (BluetoothDevice device : pairedDevices1) {
        			HashMap<String, Object> map = new HashMap<String, Object>();
        			if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.PHONE) {
        				map.put("typeImage", R.drawable.phone);
        			} 
        			else if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.COMPUTER){
        				map.put("typeImage", R.drawable.notebook);
        			}
        			else if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.AUDIO_VIDEO){
        				map.put("typeImage", R.drawable.headphone);
        			}
        			else if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.WEARABLE){
        				map.put("typeImage", R.drawable.watch);
        			}
        			else {
        				map.put("typeImage", R.drawable.machine);
        			}
        			map.put("deviceName", device.getName());
        			map.put("deviceAddress", device.getAddress());
        			map.put("onRightImage", R.drawable.onright);
        			childenListItemData.get(0).add(map);
            }
            pListView.expandGroup(0);
			mPairedDevicesAdapter.notifyDataSetChanged();
        }
        
        

        // Register for broadcasts when a device is discovered
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        this.registerReceiver(mReceiver, filter);//ע��㲥����������ϵͳ��BluetoothDevice.ACTION_FOUND�Ĺ㲥����ʱ����ִ��mReceiver

        // Register for broadcasts when discovery has finished
        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        this.registerReceiver(mReceiver, filter);//ע��㲥������
        
        filter = new IntentFilter(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        this.registerReceiver(mReceiver, filter);//ע��㲥������
        
        filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        this.registerReceiver(mReceiver, filter);//ע��㲥������

    }

    @Override
    protected void onDestroy() {//��ͼ���ر�ʱִ��
        super.onDestroy();

        // Make sure we're not doing discovery anymore
        if (mBtAdapter != null) {
            mBtAdapter.cancelDiscovery();//ȡ������
        }

        // Unregister broadcast listeners
        this.unregisterReceiver(mReceiver);//ע���㲥������
    }

	public void getMyBTInfo() {
		if (mBtAdapter!=null&&mBtAdapter.isEnabled()) {
			myBluetoothName = mBtAdapter.getName();
			myBluetoothAddress = mBtAdapter.getAddress();
			if (mBtAdapter.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
				isDiscoverable = true;
			}
		}
	}

    private void discoveryable() {//ʹ�����豸�ɼ�
        if (mBtAdapter.getScanMode() !=
                BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {//SCAN_MODE_CONNECTABLE_DISCOVERABLE��ʾ�豸�ȿ��Ա�Զ�������豸���֣�Ҳ���Ա�������
                Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);//���������豸�ɱ�����
                discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120);//���������豸�ɱ����ֵĳ���ʱ��
                startActivity(discoverableIntent);
                discoveryableTimer.start();
            }
    }
    /**
     * Start device discover with the BluetoothAdapter
     */
    private void doDiscovery() {//���������豸
        if (D) Log.d(TAG, "doDiscovery()");


        // If we're already discovering, stop it
        if (mBtAdapter.isDiscovering()) {//�����������
            mBtAdapter.cancelDiscovery();//ȡ������
        }

        // Request discover from BluetoothAdapter
        mBtAdapter.startDiscovery();//��ʼ���������豸
    }

    // The on-click listener for all devices in the ListViews
    private OnItemClickListener mDeviceClickListener = new OnItemClickListener() {
        public void onItemClick(AdapterView<?> av, View view, int arg2, long arg3) {
            // Cancel discovery because it's costly and we're about to connect
            mBtAdapter.cancelDiscovery();//ȡ������

			TextView tv = (TextView) view.findViewById(R.id.tv_deviceAddress);
			String address = tv.getText().toString();
            // Create the result Intent and include the MAC address
            Intent intent = new Intent();
            intent.putExtra(EXTRA_DEVICE_ADDRESS, address);//֪ͨ����Activity������������豸�ĵ�ַ

            // Set result and finish this Activity
            setResult(Activity.RESULT_OK, intent);//���ø�Activity���صĽ�������ݣ�������ַ��
            finish();//�������Activity
        }
    };

    // The BroadcastReceiver that listens for discovered devices and
    // changes the title when discovery is finished
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {//�㲥������
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();//���չ㲥����

            // When discovery finds a device
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {//����ҵ��豸
				updateFoundDevicesListView(intent);
            // When discovery is finished, change the Activity title
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {//����������
        		Button scanButton = (Button)findViewById(R.id.button_scan);
        		scanButton.setText(R.string.button_scan);
        		findViewById(R.id.txt_state_search).setVisibility(View.GONE);
            }
            else if (BluetoothAdapter.ACTION_SCAN_MODE_CHANGED.equals(action)) {
				if (mBtAdapter.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
					// �����������ɼ�״̬ʱ��checkbox����Ҫ�ָ�ԭװ��ͨ��isChangeToDiscoverable����
					cb_isDiscoverable.setChecked(true);
					cb_isDiscoverable.setEnabled(false);

				} else {
					tv_myDeviceState.setText(myBluetoothAddress + "(���ɼ�)");
					cb_isDiscoverable.setChecked(false);
					cb_isDiscoverable.setEnabled(true);
				}
			}
        }
    };


	/**
	 * 
	 * Desc: ����listview Params:mSimpleAdapter ������ listview�б� Return:void
	 */
	public void updateListView(SimpleAdapter mSimpleAdapter, ListView listview) {
		mSimpleAdapter.notifyDataSetChanged();
		// setListViewHeightBasedOnChildren(listview);
	}
	/**
	 * 
	 * Desc: ���������豸listview Params:intent ����������������ϵͳ�㲥 Return:void
	 */
	public void updateFoundDevicesListView(Intent intent) {
		BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

		if (device.getBondState() != BluetoothDevice.BOND_BONDED)// ���û����Խ��豸���ƺ͵�ַ����array
		{
			Log.e(TAG, device.getAddress());
        		for(int i=0;i<childenListItemData.get(1).size();i++){
                	String str = (String) childenListItemData.get(1).get(i).get("deviceAddress");
            		if(str.equalsIgnoreCase(device.getAddress())){//�б����Ѿ�����
            			return;
            		}
            	}
			
			HashMap<String, Object> map = new HashMap<String, Object>();
			if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.PHONE) {
				map.put("typeImage", R.drawable.phone);
			} 
			else if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.COMPUTER){
				map.put("typeImage", R.drawable.notebook);
			}
			else if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.AUDIO_VIDEO){
				map.put("typeImage", R.drawable.headphone);
			}
			else if (device.getBluetoothClass().getMajorDeviceClass() == BluetoothClass.Device.Major.WEARABLE){
				map.put("typeImage", R.drawable.watch);
			}
			else {
				map.put("typeImage", R.drawable.machine);
			}
			
			map.put("deviceName", device.getName());
			map.put("deviceAddress", device.getAddress());
			map.put("onRightImage", R.drawable.onright);
			childenListItemData.get(1).add(map);
			pListView.expandGroup(1);
			mPairedDevicesAdapter.notifyDataSetChanged();
		}
		
	}
}
